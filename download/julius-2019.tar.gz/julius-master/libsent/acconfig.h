/* $Id: acconfig.h,v 1.1.1.1 2007/09/28 02:50:55 sumomo Exp $ */
/* use microphone input */
#undef USE_MIC

/* use Datlink/Netaudio input */
#undef USE_NETAUDIO

/* libsndfile support */
#undef HAVE_LIBSNDFILE

/* use integer word WORD_ID (for over 60k word) */
#undef WORDS_INT

/* use addlog array */
#undef USE_ADDLOG_ARRAY

/* zcat command */
#undef ZCAT

/* have socklen */
#undef HAVE_SOCKLEN_T

/* have POSIX thread */
#undef HAVE_PTHREAD
