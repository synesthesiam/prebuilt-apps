
import base

import voidtype
import inttype
import stringtype
import booltype
import doubletype
import floattype
import pyobjecttype


from base import add_type_alias

