__version__ = [0, 16, 0]
"""[major, minor, micro, revno], revno omitted in official releases"""
